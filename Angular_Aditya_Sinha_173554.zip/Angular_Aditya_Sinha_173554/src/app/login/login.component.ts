import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userId : string;
  password : string;
  submitted : boolean;
  constructor(private router: Router, private serviceService: ServiceService) {
    this.userId="addi091@gmail.com";
    this.password="aditya562";
    
   }

 
login() {
  this.serviceService.checkLogin(this.userId,this.password)
  
}

validate() {
  this.submitted = true;
  console.log(this.userId + " = " + this.password);
}
}
