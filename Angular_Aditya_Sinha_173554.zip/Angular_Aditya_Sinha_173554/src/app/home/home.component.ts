import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ModelTodo } from '../models/modeltodo';
import { ServiceService } from '../services/service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @Input() studentDetails: ModelTodo;
  @Output() editComplete = new EventEmitter();
  @Input() buttonEditStatus = false;
  todoDetails: ModelTodo;
  

  constructor(private serviceService: ServiceService, private route: ActivatedRoute, private router: Router) { 
    this.todoDetails = new ModelTodo();
  }
  ngOnInit() {

  }
  onSubmit() {
    // set todo details to service
    
    this.router.navigate(['/login']);
   
  }
 

}
