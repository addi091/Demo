import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {
  public tasks: any[];
  constructor(private router: Router, private serviceService: ServiceService) { }

  ngOnInit() {

  }
  
  onSubmit() {
    // set todo details to service
    
    this.router.navigate(['/create']);
   
  }

}
