export class ModelTodo {
    name: String;
    status: String;
    
}