import { Injectable } from '@angular/core';
import { ModelTodo } from '../models/modeltodo';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  [x: string]: any;

  todoArrOfObj: ModelTodo[];
  searchResult: ModelTodo;
  editStatus = false; // maintains status for edit/submit data
  constructor(private router: Router) {
      this.todoArrOfObj = [];
   }

   settodoDetails(todoDetails: ModelTodo) {
    // push details object into array of objects
    this.todoArrOfObj.push(todoDetails);
    
    this.router.navigate(['/todos']);
  }
  
  deletetodoRecord(index: any) {
    this.todoArrOfObj.splice(index , 1);
  }
 
  
 
  checkLogin(userId, password) {
    if(userId=="addi091@gmail.com" && password=="aditya562") {
      this.router.navigate(['/todos']);
    }
    else {
      console.log("invalid details");
    }
  }
}
