import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../services/service.service';
import { ModelTodo } from '../models/modeltodo';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  @Input() studentDetails: ModelTodo;
  @Output() editComplete = new EventEmitter();
  @Input() buttonEditStatus = false;

  constructor(private router: Router, private serviceService: ServiceService) { }

  ngOnInit() {
  }
  onSubmit() {
    // set todo details to service
    
    this.router.navigate(['/todos']);
   
  }
  update() {
    this.router.navigate(['/todos']);
    this.serviceService.editStatus = false;
    this.editComplete.emit();
  }

}
