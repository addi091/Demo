package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Customer;
import com.cg.repo.CustomerRepo;


@Repository
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepo repo;
	
	

	
	@Transactional(propagation=Propagation.REQUIRED)
	public void saveCustomer(Customer c) {
		repo.save(c);
	}

	@Transactional(propagation=Propagation.SUPPORTS)
	public Customer get(int id) {
		return repo.findById(id).get();
		
	}

    @Transactional
	public Iterable<Customer> getAll() {
		return repo.findAll();
	}

	@Override
	public Customer update(Customer c, int id) {
		c.setId(id);
		repo.save(c);
		return c;
	}


    @Transactional
	public String deleteProduct(int id) {
    	Customer c1 = repo.findById(id).get();
	    repo.delete(c1);
	    return "Delete Successfully";
	    
	}

}
