package com.cg.jpalab2.client;

import java.util.Scanner;

import com.cg.jpalab2.entities.Author;
import com.cg.jpalab2.entities.Book;
import com.cg.jpalab2.service.AuthorBookService;
import com.cg.jpalab2.service.AuthorBookServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		AuthorBookService service = new AuthorBookServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		
		
		Author author = new Author();
		Book book = new Book();
		System.out.println("Enter the ISBN of the book");
		int isbn = sc.nextInt();
		book.setISBN(isbn);
		System.out.println("Enter the title of thge book");
		String title = sc.next();
		book.setTitle(title);
		System.out.println("Enter the price of the book");
		Double price = sc.nextDouble();
		book.setPrice(price);
		service.insertBook(book);
	    author.addBooks(book);
		System.out.println(book);
		System.out.println("Enter the author id");
		int id = sc.nextInt();
		author.setId(id);
		System.out.println("Enter the author name");
		String name = sc.next();
		author.setName(name);
		service.insertAuthor(author);
		
	}
}
