/**
 * 
 */
package com.cg.jpalab2.service;

import com.cg.jpalab2.entities.Author;
import com.cg.jpalab2.entities.Book;

/**
 * @author Aditya Sinha
 *
 */
public interface AuthorBookService {
	
	
	public abstract Book getBookDetails(int id);
	
	public abstract void insertBook(Book book);
	
	public abstract void insertAuthor(Author author);
	

}
