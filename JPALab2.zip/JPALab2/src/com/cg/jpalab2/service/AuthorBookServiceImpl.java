/**
 * 
 */
package com.cg.jpalab2.service;

import com.cg.jpalab2.dao.AuthorBookDao;
import com.cg.jpalab2.dao.AuthorBookDaoImpl;
import com.cg.jpalab2.entities.Author;
import com.cg.jpalab2.entities.Book;

/**
 * @author Aditya Sinha
 *
 */
public class AuthorBookServiceImpl implements AuthorBookService {
	
	AuthorBookDao dao;
	public AuthorBookServiceImpl() {
		dao = new AuthorBookDaoImpl();
	}

	@Override
	public Book getBookDetails(int id) {
		return dao.getBookDetails(id);
	}

	@Override
	public void insertBook(Book book) {
		dao.beginTransaction();
		dao.insertBook(book);
		dao.commitTransaction();
		
	}

	@Override
	public void insertAuthor(Author author) {
		dao.beginTransaction();
		dao.insertAuthor(author);
		dao.commitTransaction();
	}

}
