package com.cg.jpalab2.dao;

import com.cg.jpalab2.entities.Author;
import com.cg.jpalab2.entities.Book;

/**
 * @author Aditya Sinha
 *
 */
public interface AuthorBookDao {

	public abstract Book getBookDetails(int id);
	
	
	
	public abstract Book getByAuthorName(Author author);
	
	public abstract void insertBook(Book book);
	
	public abstract void insertAuthor(Author author);
	
	public abstract void beginTransaction();
	
	public abstract void commitTransaction();
	
}
