/**
 * 
 */
package com.cg.jpalab2.dao;

import javax.persistence.EntityManager;

import com.cg.jpalab2.dao.JPAUtil;
import com.cg.jpalab2.entities.Author;
import com.cg.jpalab2.entities.Book;

/**
 * @author Aditya Sinha
 *
 */
public class AuthorBookDaoImpl implements AuthorBookDao {
	
	private EntityManager entityManager;
	
	public AuthorBookDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public Book getBookDetails(int id) {
		Book book = entityManager.find(Book.class, id);
		
		return book;
	}

	@Override
	public Book getByAuthorName(Author author) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertBook(Book book) {
		entityManager.persist(book);
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void insertAuthor(Author author) {
		entityManager.persist(author);
		
	}

}
