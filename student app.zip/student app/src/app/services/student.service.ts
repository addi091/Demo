import { Injectable } from '@angular/core';
import { StudentModel } from '../model/student-model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  studentArrOfObj: StudentModel[];
  searchResult: StudentModel;
  editStatus = false; // maintains status for edit/submit data
  constructor(private router: Router) {
      this.studentArrOfObj = [];
   }

  setStudentDetails(studentDetails: StudentModel) {
    // push details object into array of objects
    this.studentArrOfObj.push(studentDetails);
    alert('Registered successfully!');
    this.router.navigate(['/display']);
  }
  getStudentDetails() {
  // retrive all records from array
   return this.studentArrOfObj;
  }
  deleteStudentRecord(index: any) {
    this.studentArrOfObj.splice(index , 1);
  }
  search(rollno: number) {
    this.searchResult = this.studentArrOfObj.find(x => x.rollno === rollno);
    if (this.searchResult === null) {
       return null;
    } else {
      return this.searchResult;
    }
  }

  sort() {
    this.studentArrOfObj.sort((a, b) => a.rollno > b.rollno ? 1 : ((a.rollno < b.rollno) ? -1 : 0));
    return this.studentArrOfObj;
  }
  editStudentRecord(rollno) {
    // fetch details
    this.searchResult = this.studentArrOfObj.find(x => x.rollno === rollno);
    return this.searchResult;
  }
  getRecord() {
    // return fetched result to prefill data in register component
    return this.searchResult;
  }
  checkLogin(userId,password) {
    if(userId=="aditya" && password=="aditya562") {
      this.router.navigate(['/display']);
    }
    else {
      console.log("invalid details");
    }
  }
}

