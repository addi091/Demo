import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { StudentService } from '../services/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentModel } from '../model/student-model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @Input() studentDetails: StudentModel;
  @Output() editComplete = new EventEmitter();
  @Input() buttonEditStatus = false;
  constructor(private studentService: StudentService, private route: ActivatedRoute, private router: Router) { 
    this.studentDetails = new StudentModel();
  }
  ngOnInit() {

  }
  onSubmit() {
    // set student details to service
    this.studentService.setStudentDetails(this.studentDetails);
  }
  update() {
    alert('Updated successfully!');
    // navigate to ListOfStudents page on update
    this.router.navigate(['/display']);
    this.studentService.editStatus = false;
    this.editComplete.emit();
  }
}

