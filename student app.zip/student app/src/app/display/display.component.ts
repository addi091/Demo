import { Component, OnInit } from '@angular/core';
import { StudentModel } from '../model/student-model';
import { Router } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  public students: any[];
  public editStatus = false;
  editedStudent: StudentModel;
  constructor(private router: Router, private studentService: StudentService) { }

  ngOnInit() {
    this.students = this.studentService.getStudentDetails();
  }
  navigateToRegister() {
    this.router.navigate(['/register']);
  }
  deleteRecord(index) {
    this.editStatus = false;
    // delete record from service using index of record in array
    this.studentService.deleteStudentRecord(index);
  }
  editRecord(rollno) {
    this.editStatus = true;
    this.editedStudent = this.studentService.editStudentRecord(rollno);
  }
  sortByRollNo() {
    this.students =  this.studentService.sort();
  }
}
