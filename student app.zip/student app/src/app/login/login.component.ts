import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userId : string;
  password : string;
  submitted : boolean;
  constructor(private router: Router, private studentService: StudentService) {
    this.userId="aditya";
    this.password="aditya562";
    
   }

 
login() {
  this.studentService.checkLogin(this.userId,this.password)
  
}

validate() {
  this.submitted = true;
  console.log(this.userId + " = " + this.password);
}
}
