package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;


@Service
@Transactional
public class AlbumServiceImpl implements AlbumService {

	
	@Autowired
	private AlbumRepo repo;
	
	
	@Override
	public void saveAlbum(Album a) {
		repo.save(a);
	}

	@Override
	public Iterable<Album> getAllAlbum() {
		return repo.findAll();
	}

	@Override
	public Album getById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public Album updateAlbum(Album a, int id) {
		a.setId(id);
		repo.save(a);
		return a;
	}

	@Override
	public String deleteAlbum(int id) {
        Album a1 = repo.findById(id).get();
        repo.delete(a1);
		return "Deleted Successfully";
	}

	@Override
	public Album getAlbum(int id) throws NoSuchElementException {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Album Record Found For Id " + id);
		}
	}

	
	@Override
	public Album findByTitle(String title) {
		return repo.findByTitle(title);
	}

	
}
