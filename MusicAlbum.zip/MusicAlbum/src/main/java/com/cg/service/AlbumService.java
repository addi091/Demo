package com.cg.service;

import java.util.NoSuchElementException;

import com.cg.entity.Album;

public interface AlbumService {
	
	Album getAlbum(int id) throws NoSuchElementException;
	
	public void saveAlbum(Album a);
	
	public Iterable<Album> getAllAlbum();
	
	public Album getById(int id);
	
	public Album updateAlbum(Album a, int id);
	
	public String deleteAlbum(int id);
	
	Album findByTitle(String title);
	
	

}
