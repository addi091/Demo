package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;


@SpringBootApplication
public class ProductBootApplication {
	
	

	public static void main(String[] args) {
		SpringApplication.run(ProductBootApplication.class, args);
	}


	
}
