package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
import com.cg.service.ProductService;

@RestController
public class ProductController {


	@Autowired
	private ProductService service;
	

	@GetMapping("/hi")
	public String get() {
		return "HIIi Aaditya";
	}
	
	@GetMapping("/all")
	public Iterable<Product> getAll() {
		return service.getAll();
	}
	
	@PostMapping("/add")
	public String saveProduct(@RequestParam("name") String name,
			@RequestParam ("price") double price) {
	 Product p = new Product();
	 p.setName(name);
	 p.setPrice(price);
	 service.saveProduct(p);
	 return "Product Saved";
	 }


	@GetMapping(name="/product" ,produces= "application/json")
	public Product getProduct(@RequestParam("id") int id) {
		 Product p = service.get(id);
	 return p;
	}
	
	@PutMapping(path ="/update/{id}", consumes = "application/json")
	public Product update(@PathVariable("id") int id, @RequestBody Product p) {
		return service.update(p, id);
		
	
	}
	
	@DeleteMapping(path ="/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		return service.deleteProduct(id);
	}

}
