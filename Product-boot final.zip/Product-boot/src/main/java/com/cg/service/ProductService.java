package com.cg.service;

import java.util.List;

import com.cg.entity.Product;

public interface ProductService {
	
   void saveProduct(Product p);
	
	Product get(int id);
	
	Iterable<Product> getAll();
	
	public String deleteProduct(int id);

	public Product update(Product p, int id);
	
}
