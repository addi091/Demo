package com.cg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Product;

public interface ProductRepo extends CrudRepository<Product, Integer> {

	
	
}
